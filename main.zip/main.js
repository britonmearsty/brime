function showMenu(){
    const open = document.querySelector(".menu");
    open.style.display = 'block';
}
function hideMenu(){
    const open = document.querySelector(".menu");
    open.style.display = 'none';
}